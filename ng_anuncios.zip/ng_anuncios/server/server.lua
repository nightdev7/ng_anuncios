ESX = nil
TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)


RegisterCommand("ad", function(source, args)
	local xPlayer = ESX.GetPlayerFromId(source)
	local argString = table.concat(args, " ")
	if xPlayer.job.name == 'police' then
		TriggerClientEvent('ng_anuncios:client:SendAlert', -1, { type = 'lspd', text = argString})
	elseif xPlayer.job.name == 'ambulance' then
		TriggerClientEvent('ng_anuncios:client:SendAlert', -1, { type = 'ems', text = argString})	
	elseif xPlayer.job.name == 'mechanic' then
		TriggerClientEvent('ng_anuncios:client:SendAlert', -1, { type = 'mecanico', text = argString})
	elseif xPlayer.job.name == 'taxi' then
        TriggerClientEvent('ng_anuncios:client:SendAlert', -1, { type = 'taxi', text = argString})
    end
end, false)
